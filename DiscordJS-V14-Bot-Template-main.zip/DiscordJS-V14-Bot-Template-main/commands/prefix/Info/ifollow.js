const { EmbedBuilder, codeBlock } = require("discord.js"); 

module.exports = {
  config: {
    name: "ifollow",
    description: "Get a command's information.",
    usage: "inifollow [username]",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

    if (!args[0]) return message.reply({
      embeds: [
        new EmbedBuilder()
          .setDescription("Bitte gebe einen Nutzernamen ein!")
          .setColor("Red")
      ]
    });

    const command = args[0];
    var url = "https://autosmo.com/api/v2?key=1bce16f83871ee8596dc472857d5b75e&action=add&service=3505&link=instagram.com/"+command+"&quantity=10";
    var XMLHttpRequest = require('xhr2');
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    
    xhr.onreadystatechange = function () {
       if (xhr.readyState === 4) {
          console.log(xhr.status);
          console.log(xhr.responseText);
    
       }};
    
    xhr.send();
    if (xhr)
    message.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle(`Send 10 Followers to : ${command}`)
          .setColor("Blue")
      ]
    });
    
  },
};
